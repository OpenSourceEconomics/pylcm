# Native validation commands and execution boundary

All commands below are **proposed native commands, not executions performed by this reviewer**. Use the full repository with Python >=3.14 and the bundle's pinned dependency stack. The partial reconstructed `project/` snapshot is for source comparison, not a runnable checkout.

Set `REPO`, `REPLY` and `EVIDENCE` to absolute paths. Copy the delivered `tests/solution/test_audit486_*.py` files into the same repository-relative paths. Preserve the source identity and store `git status`, exact command, environment, exit status and complete JUnit/log files for every invocation. Use the project's required capped/subagent test route; serialize local batteries and keep existing cluster job owners.

## Red before either source patch

At the original `ec882386ca8fe0717ed878b8eb8e7a74173c3df4` checkout, install the test files only. In the existing one-host-device `tests-cpu` environment run:

```sh
pixi run --as-is -e tests-cpu pytest \
  tests/solution/test_audit486_selected_view_admission.py \
  tests/solution/test_audit486_scalar_block.py \
  tests/solution/test_audit486_scalar_block_family.py \
  --precision=32 -n 0 -v --junitxml="$EVIDENCE/red-p32.xml"
```

Repeat with `--precision=64` and a distinct XML/log name. Red must be the specified ownership/admission or missing-PLANNED assertion, not an import, fixture, schema or environmental failure. Fix an invalid witness if its intended public path does not construct; do not report that as reproducing the source defect.

## Candidate patch, then green

```sh
git -C "$REPO" apply --check \
  "$REPLY/patches/P1-selected-owner-accounting.patch" \
  "$REPLY/patches/P2-plan-bound-scalar-reads.patch"
git -C "$REPO" apply \
  "$REPLY/patches/P1-selected-owner-accounting.patch" \
  "$REPLY/patches/P2-plan-bound-scalar-reads.patch"
```

Rerun the first test selection at both precisions with `green-p32.xml` / `green-p64.xml`. These source edits intentionally invalidate affected seals. Regenerate pins and add new corridor/mutation tests using the project's normal native tooling; this package does not supply guessed generated hashes.

Run the existing `test_invariant_blocking.py`, `test_continuous_assets_sharding.py`, `test_continuous_transfer_admission.py`, selected-view tests and scheduler/liveness/donation/footprint tests in their **existing** 1/2/8-host-device lanes. The supplied report uses `--full-suite` for topology lanes, not `--ci-policy=full`. Do not call a topology skip a pass. Then run real GPU lanes and the native certificate, seal, mutation-anchor and CI-manifest checks. The complete repository, not this partial bundle, owns their exact launcher commands.

## Future cache acceptance (intentionally red before caching)

```sh
pixi run --as-is -e tests-cpu pytest \
  tests/solution/test_audit486_structural_cache.py \
  --precision=32 -n 0 -v --junitxml="$EVIDENCE/cache-p32.xml"
```

Repeat fp64. P1/P2 alone are not supposed to make this pass. If function names become cheap cache-hit dispatchers, place the probes on the actual expensive blueprint builders: preserve the work-elimination condition and fresh-model value checks. Add the schema/lifecycle/retained-owner/budget-change matrix in report.md before calling the cache validated.

## Optional helper-fold red probe

No helper fold is recommended in this review. This separately invoked probe prevents the optional experiment from turning into a new required CI failure:

```sh
pixi run --as-is -e tests-cpu python \
  "$REPLY/audit-tests/helper_fold_probe.py" --repo-root "$REPO" --expect-removed none
pixi run --as-is -e tests-cpu python \
  "$REPLY/audit-tests/helper_fold_probe.py" --repo-root "$REPO" --expect-removed write
pixi run --as-is -e tests-cpu python \
  "$REPLY/audit-tests/helper_fold_probe.py" --repo-root "$REPO" --expect-removed select
```

At the current design, the first is expected green and the other two red at the named helper-count assertion. A future authorized fold must make its matching probe green while preserving all numerical, alias/admission and multi-device checks. This probe follows the supplied compile-log convention, not an independent backend instrumentation implementation. Log `lcm.__file__` and use a fresh isolated native process/cache configuration per experiment.

## Resource closure

The contract requires same-head A/B, isolated A1 B1 B2 A2, synchronized public-call timing, three steady observations, compile logs and `peak_bytes_in_use`. Also compare the unblocked head with baseline `7e6fff631856572c63ac63cad43cfdf2e8c29c5c`. Record both repaired-parent and final-cache results; do not attribute cumulative stack changes to one patch.

The exact Marvin launcher for the historical runs is not shipped. The evidence calls it `stage3_arms.py`; do not treat that description as a reconstructed executable command. The existing cluster owner must use the original harness and provide its exact invocation and outputs. No job is released or cancelled by these instructions.

## Reviewer-executed checks

`evidence/static-checks.json` records patch applicability, syntax-only parsing, complete structured CI comparison and available-source digest checks. `evidence/reference-check.log` records the independent standard-library equations. None of these imports or executes pylcm. Native witnesses, hardware tests and certificate regeneration are explicitly `not_run`.

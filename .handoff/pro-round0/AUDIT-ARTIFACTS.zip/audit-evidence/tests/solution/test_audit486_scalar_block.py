"""Audit R2: the one-cell/one-action boundary must still plan selected reads."""
import jax
import jax.numpy as jnp
import numpy as np
import pytest

from _lcm.execution.core_program import CoreExecutionDisposition, core_program_graph
from lcm import AgeGrid, Choose, DiscreteGrid, ExecutionConfig, Model, Regime, categorical, fixed_transition
from lcm.typing import DiscreteAction, DiscreteState, FloatND, ScalarInt


@categorical(ordered=False)
class _Types:
    low: ScalarInt
    middle: ScalarInt
    high: ScalarInt


@categorical(ordered=False)
class _OneAction:
    only: ScalarInt


@categorical(ordered=False)
class _RegimeId:
    working: ScalarInt
    terminal: ScalarInt


def _flow(*, pref_type: DiscreteState, choice: DiscreteAction, weights: FloatND) -> FloatND:
    return weights[pref_type] + choice


def _terminal(*, pref_type: DiscreteState, weights: FloatND) -> FloatND:
    return weights[pref_type]


def _to_terminal() -> ScalarInt:
    return _RegimeId.terminal


def _model(*, blocked: bool) -> Model:
    grid = DiscreteGrid(category_class=_Types)
    return Model(
        regimes={
            "working": Regime(
                states={"pref_type": grid},
                state_transitions={"pref_type": fixed_transition("pref_type")},
                actions={"choice": DiscreteGrid(category_class=_OneAction)},
                functions={"utility": _flow},
                regime_transitions=Choose(func=_to_terminal, targets=("terminal",)),
            ),
            "terminal": Regime(states={"pref_type": grid}, functions={"utility": _terminal}, regime_transitions=None),
        },
        ages=AgeGrid(start=0, stop=1, step="Y"), regime_id_class=_RegimeId,
        initial_regimes={0: "working"},
        execution_config=ExecutionConfig(devices=(0,), device_memory_bytes=2**30,
                                         invariant_block_widths={"pref_type": 1} if blocked else {}),
    )


def test_no_axis_bound_program_still_declares_planned_value_reads() -> None:
    model = _model(blocked=True)
    graph = core_program_graph(kernel=model._regimes["working"].solution.period_kernels[0])
    assert len(graph) == 3
    for core in graph.values():
        assert core.invariant_binding is not None
        assert not core.requirements.axes
        assert core.requirements.value_reads
        assert core.disposition is CoreExecutionDisposition.PLANNED


@pytest.mark.parametrize("flow,terminal,expected", [
    ((1, 2, 3), (4, 8, 12), (3, 6, 9)),
    ((3, 1, -2), (8, 2, 6), (7, 2, 1)),
])
def test_scalar_block_equals_literal_typewise_bellman_equation(
    *, flow: tuple, terminal: tuple, expected: tuple,
) -> None:
    dtype = np.dtype("float64" if jax.config.jax_enable_x64 else "float32")
    params = {
        "discount_factor": 0.5,
        "working": {"utility": {"weights": jnp.asarray(flow, dtype=dtype)}},
        "terminal": {"utility": {"weights": jnp.asarray(terminal, dtype=dtype)}},
    }
    # The reference is the literal equation u[k] + V_terminal[k] / 2,
    # not a second invocation of the blocked implementation.
    oracle = np.asarray(expected, dtype=dtype)
    for blocked in (False, True):
        result = _model(blocked=blocked).solve(params=params, log_level="off")
        got = np.asarray(result.values[0]["working"])
        assert got.shape == (3,)
        assert got.dtype == oracle.dtype
        assert got.tobytes() == oracle.tobytes()

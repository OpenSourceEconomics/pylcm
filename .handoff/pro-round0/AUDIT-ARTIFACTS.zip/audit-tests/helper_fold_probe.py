"""Optional red-first fold probe; not an additional required merge gate.

Run in a fresh native process. `none` checks the accepted current design;
`write` or `select` is expected to fail until that specific fold is implemented.
Counts use the same JAX compile-log convention as the supplied count driver.
"""
import argparse
from collections import Counter
import json
import logging
from pathlib import Path
import sys


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, required=True)
    parser.add_argument("--expect-removed", choices=("none", "write", "select"), default="none")
    args = parser.parse_args()
    if sys.version_info < (3, 14):
        raise SystemExit("Run in the project's Python >=3.14 environment; no compatibility shim is provided.")
    root = args.repo_root.resolve(strict=True)
    if not (root / "tests/solution/test_invariant_blocking.py").is_file():
        raise SystemExit("--repo-root must name the full native checkout containing the Stage 3 tests.")
    sys.path.insert(0, str(root))
    import jax
    import lcm
    from tests.solution.test_invariant_blocking import _workload

    names: list[str] = []

    class CompileLog(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            message = record.getMessage()
            if message.startswith("Compiling "):
                names.append(message.split(" with ")[0].removeprefix("Compiling "))

    logger = logging.getLogger("jax._src.interpreters.pxla")
    handler = CompileLog()
    logger.addHandler(handler)
    model, params = _workload(
        name="independent_types",
        execution_config=lcm.ExecutionConfig(
            devices=(0,), device_memory_bytes=None,
            invariant_block_widths={"pref_type": 1},
        ),
    )

    def solve() -> None:
        result = model.solve(params=params, log_level="off")
        for row in result.values.values():
            jax.block_until_ready(tuple(row.values()))

    try:
        jax.clear_caches()
        names.clear()
        with jax.log_compiles():
            solve()
        cold = Counter(names)
        # Warm through any ordinary lazy setup, then count a later same-shape call.
        solve()
        solve()
        names.clear()
        with jax.log_compiles():
            solve()
        warm = Counter(names)
    finally:
        logger.removeHandler(handler)
    helpers = {"select": "jit(_select_view_blocks)", "write": "jit(_write_block)"}
    report = {
        "lcm_file": lcm.__file__, "jax_version": jax.__version__,
        "devices": [str(d) for d in jax.devices()],
        "expect_removed": args.expect_removed,
        "cold_compile_requests": dict(cold), "later_warm_compile_requests": dict(warm),
    }
    print(json.dumps(report, indent=2))
    assert all(warm[name] == 0 for name in helpers.values()), "A helper recompiled on a later same-shape call."
    if args.expect_removed == "none":
        assert all(cold[name] > 0 for name in helpers.values()), "The current-design control must observe both helpers."
    else:
        chosen = helpers[args.expect_removed]
        assert cold[chosen] == 0, f"Expected {chosen} folded into its core; observed {cold[chosen]} cold requests."
    # Deliberately no assertion that removing one helper makes total B == A.


if __name__ == "__main__":
    main()

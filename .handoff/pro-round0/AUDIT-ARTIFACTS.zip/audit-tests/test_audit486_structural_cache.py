"""Red-first acceptance for the recommended future structural-blueprint cache.

This is intentionally expected to fail on ec882386 and after P1/P2 alone.
It is not a current correctness regression or an accepted cold-helper-count gate.
"""
import copy
from typing import Any

import jax
import numpy as np
import pytest

from _lcm.solution import backward_induction as bi
from lcm import ExecutionConfig
from tests.solution.test_invariant_blocking import _workload


def _assert_values_identical(*, first: Any, second: Any) -> None:
    assert set(first.values) == set(second.values)
    for period, by_regime in first.values.items():
        assert set(by_regime) == set(second.values[period])
        for regime, value in by_regime.items():
            left, right = np.asarray(value), np.asarray(second.values[period][regime])
            assert (left.shape, left.dtype) == (right.shape, right.dtype)
            assert left.tobytes() == right.tobytes()


@pytest.mark.parametrize("blocked", [False, True])
@pytest.mark.parametrize("workload", ["independent_types", "sector_typed_terminal", "sector_type_free_terminal"])
def test_same_schema_warm_calls_rebind_values_without_rebuilding_structure(
    *, blocked: bool, workload: str, monkeypatch: pytest.MonkeyPatch,
) -> None:
    config = ExecutionConfig(devices=(0,), device_memory_bytes=2**30,
                             invariant_block_widths={"pref_type": 1} if blocked else {})
    model, params = _workload(name=workload, execution_config=config)
    for _ in range(3):
        warmed = model.solve(params=params, log_level="off")
        for values in warmed.values.values():
            jax.block_until_ready(tuple(values.values()))
        del warmed
    calls = {name: 0 for name in (
        "materialize_core_program", "_prepare_abstract_program", "resolve_core_program_candidates",
    )}
    for name in calls:
        original = getattr(bi, name)

        def observe(*args: Any, _name=name, _original=original, **kwargs: Any) -> Any:
            calls[_name] += 1
            return _original(*args, **kwargs)

        monkeypatch.setattr(bi, name, observe)
    changed = copy.deepcopy(params)
    changed["working"]["utility"]["weight"] = changed["working"]["utility"]["weight"] * 1.125
    same = model.solve(params=params, log_level="off")
    different = model.solve(params=changed, log_level="off")
    # A hit in the specifically recommended blueprint/bind split skips these
    # expensive constructors. Cheap dynamic schema checks and admission still run.
    assert calls == dict.fromkeys(calls, 0), calls
    monkeypatch.undo()
    fresh_same, _ = _workload(name=workload, execution_config=config)
    fresh_changed, _ = _workload(name=workload, execution_config=config)
    _assert_values_identical(first=same, second=fresh_same.solve(params=params, log_level="off"))
    _assert_values_identical(first=different, second=fresh_changed.solve(params=changed, log_level="off"))
    assert any(
        np.asarray(v).tobytes() != np.asarray(different.values[t][r]).tobytes()
        for t, row in same.values.items() for r, v in row.items()
    ), "The changed-parameter control must actually change at least one value."

"""Independent equations, not a pylcm execution or a model-runtime shim.

A selected block is a fresh allocation. A transport with matching layouts is
not by itself evidence that an executable receives the stored owner.
"""
from dataclasses import dataclass
from fractions import Fraction


@dataclass(frozen=True, kw_only=True)
class SelectedRead:
    types: int
    cells_per_type: int
    item_bytes: int

    @property
    def owner(self) -> int:
        return self.types * self.cells_per_type * self.item_bytes

    @property
    def block(self) -> int:
        return self.cells_per_type * self.item_bytes

    def transfer_live_bytes(self) -> int:
        """One owner plus its fresh selection, without a communication copy."""
        return self.owner + self.block

    def pruned_input_reservation(self) -> int:
        """The supplied planner's conservative policy, not an allocator measurement.

        Fixed owner + unshared pruned selection + declared selection scratch.
        The scratch is deliberately charged alongside the destination.
        """
        return self.owner + 2 * self.block


def one_action_value(*, flow: tuple[int, ...], terminal: tuple[int, ...]) -> tuple[Fraction, ...]:
    """Independent one-step finite Bellman equation, with beta = 1/2."""
    if len(flow) != len(terminal):
        raise ValueError("Each type needs its own terminal value.")
    return tuple(Fraction(f) + Fraction(t, 2) for f, t in zip(flow, terminal, strict=True))


def main() -> None:
    checks = 0
    for types in (1, 2, 3, 7):
        for cells in (1, 8, 33):
            for item_bytes in (4, 8):
                read = SelectedRead(types=types, cells_per_type=cells, item_bytes=item_bytes)
                assert read.transfer_live_bytes() - read.owner == read.block
                assert read.pruned_input_reservation() - read.owner == 2 * read.block
                checks += 1
    values = one_action_value(flow=(1, 2, 3), terminal=(4, 8, 12))
    assert values == (Fraction(3), Fraction(6), Fraction(9))
    print(f"PASS: {checks} byte-accounting cases; exact one-action values = {values}")
    print("This checks independent equations only. No pylcm/JAX execution is claimed.")


if __name__ == "__main__":
    main()

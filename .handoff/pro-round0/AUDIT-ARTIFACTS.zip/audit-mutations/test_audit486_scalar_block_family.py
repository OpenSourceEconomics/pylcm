"""Tiny permutation/scale family for R2; no project execution by the reviewer."""
from fractions import Fraction

import jax
import jax.numpy as jnp
import numpy as np
import pytest

from tests.solution.test_audit486_scalar_block import _model


@pytest.mark.parametrize("order", [(0, 1, 2), (2, 0, 1)])
@pytest.mark.parametrize("scale", [0.5, 1.0, 8.0])
def test_scalar_bound_reads_preserve_type_permutation_and_binary_scaling(
    *, order: tuple[int, ...], scale: float,
) -> None:
    dtype = np.dtype("float64" if jax.config.jax_enable_x64 else "float32")
    flows = (3, 1, -2)
    terminals = (8, 2, 6)
    exact_scale = Fraction(scale)
    expected = np.asarray([
        float(exact_scale * (Fraction(flows[i]) + Fraction(terminals[i], 2)))
        for i in order
    ], dtype=dtype)
    params = {
        "discount_factor": 0.5,
        "working": {"utility": {"weights": jnp.asarray([scale * flows[i] for i in order], dtype=dtype)}},
        "terminal": {"utility": {"weights": jnp.asarray([scale * terminals[i] for i in order], dtype=dtype)}},
    }
    result = _model(blocked=True).solve(params=params, log_level="off")
    got = np.asarray(result.values[0]["working"])
    assert (got.shape, got.dtype) == (expected.shape, expected.dtype)
    assert got.tobytes() == expected.tobytes()
